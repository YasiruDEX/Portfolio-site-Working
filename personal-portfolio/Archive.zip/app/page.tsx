import { LandingPage } from "@/components/landing-page";
import Image from "next/image";

export default function Home() {
  return (
    <main className="">
      <LandingPage />
    </main>
  );
}
